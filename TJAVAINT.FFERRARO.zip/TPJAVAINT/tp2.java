public class tp2 {
    CrearMascota mascotaPerro (nombre, edad, raza) -> new PerroMascota (nombre, edad. raza);
    Mascota mascota = mascotaPerro.crear( nombre:"Luna", edad:3, raza:"Dogo Argentino");

}
@FunctionalInterface
interface CrearMascota {
    Mascota crear(String nombre, int edad, String raza);
    if (mascota instanceof PerroMascota) {
        System.out.print("La raza es" + ((PerroMascota)mascota) .getRaza());
    }
}