import DAO.*;
import Interfaz.usuario.VeterinarioInterfaz;
import entity.Dato;
import entity.Mascota;
import entity.Medico;
import entity.TurnoMedico;
import jakarls.persistence.EntityManager;
import jakarls.persistence.EntityManagerFactory;
import jakarls.persistence.Persistence
import service.*;

import java.util.Date;
import java.util.List;

public class turnomedicodao {

    public static void main(String[] args) {
        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory(persistence.UnitName:"defoult");
        EntityManager EntityManager +  EntityManagerFactory.createEntityManager();
        MascotaDAO mascotaDAO = new MascotaDAOImpl(entityManager);
        MascotaService  MascotaService = new     MascotaServiceImpl(mascotaDAO);

        TurnoMedicoDAO TurnoMedicoDAO = new TurnoMedicoDAOImpl(entityManager);
        TurnoMedicoService TurnoMedicoService = new TurnoMedicoServiceImpl(TurnoMedicoDAO);

        MedicoDAO medicoDAO = new MedicoDAOImpl(entityManager);
        MedicoService medicoService = new MedicoServiceImpl(medicoDAO);

        VeterinariaInterfaz veterinaria = new VeterinariaInterfaz(mascotaService, medicoService, turnoMedicoService);
        veterinaria.iniciar();
    }





}
