iimport javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Mascota {
    @Id
    @GeneratedValue(strategy = GenerattionType.IDENTITY)
    private Long id;
    private String nombre;
    private int edad;

    //constructores

}
    import org.springFramework.data.jpa.repository.JpaRepository;
    public interface MascotaRepository extends JpaRepository<Mascota, Long> {
    }
    import org.springFramework.beans.factory.annotation.Autowired;
    import org.springFramework.web.bind.annotation.*;

    import java.util.List;
    import java.util.Optional;
    import org.springFramework.beans.factory.annotation.Autowired;
    import org.springFramework.web.bind.annotation.*;

    import java.util.List;
    import java.util.Optional;

    @RestController
    @RequestMapping("/mascotas")
    public class MascotaController {

        @Autowired
        private MascotaRepository mascotaRepository;

        //obtener todas las mascotas
        @GetMapping
        public List<Mascota> obtenerTodasLasMascotas()
            return mascotaRepository.FindAll();

        //obtener mascota por id
        @GetMapping("/{id}")
        pubñic Optional<Mascota>obtenerMascotaPorId(@PathVariable Long id){
            return mascotaRepository.FindById(id);
        }
        //crear una mascota nueva
    @postMapping
    public Mascota crearMascota(@RequesBody Mascota mascota) {
        return mascotaRepository.save(mascota);
        }
        //actualizar datos de mascota
        @PutMapping("/{id}")
        public Mascota actualizarMascota(@PathVariable LONG ID, @RequestBody Mascota mascota){
            return mascotaRepositoryFindById(id);






                    . map(mascota -> {
                        mascota.setNombre(nuevaMascota.getNombre());
                        mascota.setEdad(nuevaMascota.getEdad());
                        return mascotaRepository.save(mascota);
                    })
                    .orElseGet() -> {
                        nuevaMascota.setId(id);
                        return mascotaRepository.save(nuevaMascota);

            }
        }

    }