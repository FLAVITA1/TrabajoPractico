package service;

public class MascotaServiceImpl implements MascotaService {
    private final MascotaDAO mascotaDAO;
    public  MascotaServiceImpl(MascotaDAO mascotaDAO){
        this.mascotaDAO = mascotaDAO;
    }
    @Override
    public void crearMascota(Mascota mascota) {
        mascotaDAO.crearMascota(mascota);
    }
    @Override
    public Mascota obtenerMascotaPorId(Long Id){
        return mascotaDAO.obtenerMascotaPorId(id);
    }
    @Override
    public List<Mascota> buscarPorNombre(String nombre) {
        return mascotaDAO.buacarPorNombre(nombre);
    }
}
