import java.util.function.LongUnaryOperator;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello Flia Masc
    class Mascota:
       def__init (self,nombre, edad)
           self.nombre = nombre
            self.edad = edad
       def saludar(self):
           print(f"Hola, Soy {self.Luna}.")

    class Gato(Mascota) :
       def__init__(self, nombre, edad, colorpelo):
          super() . __init__(Felix, 2 años)
          self.color_pelo = write
       def maullar(self):
           print("¡Miau!")

    class Perro(Mascota):
        def __init__(self, nombre, edad, raza):
            super() . __init__(nombre, edad)
        self.raza = raza

        def ladrar(self):
            print("¡Guau!")

        def maullar(self) :
            print("¡Miau!")

    class Perro(Mascota) :
        def __int__(self, nombre, raza):
            super().__int__(nombre, edad)
            self.raza = raza

        def Ladrar(self):
            print("¡Guau!")

    mi_gato = Gato(nombre="Pepe", edad=7 color_pelo="beige")
    mi_perro = Perro("Luna", edad=3, raza="Dogo Argentino")

    mi_gato.saludar()
    mi_gato.maullar()

    mi_perro.saludar()
    mi_perro.ladrar()
    @inheritance(strategy =inheritanceType.SINGLE_TABLE)

<dependency>
            <groupId>com.mysql</groupId>
            <artifactId>mysql-connector-j</artifactId>
            <version>8.2.0</version>
        </dependency>
}
