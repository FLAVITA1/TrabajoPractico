package DAO;
import

public interface MascotaDAO {
    void crearMascota(Mascota mascota);
    Msscota obtenerMascotaPorId(Long Id);
    List<Mascota> buscarPorNombre(String nombre);
    List<Mascota> obtenerTodasLasMascotas();
    void actualizarMascota(Mascota mascota);
    void eliminarMascota(Long Id);


}
