public class mascotacontroller {
}
